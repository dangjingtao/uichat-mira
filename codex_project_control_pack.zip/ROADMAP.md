# ROADMAP.md

## 阶段 1：核心对话模型

目标：建立稳定的消息、版本、分支数据结构。

范围：

- Message
- MessageVersion
- ConversationBranch
- BranchCursor
- Regenerate
- Edit Message
- Continue from Here

验收标准：

- 用户可以编辑历史消息。
- AI 回复可以保留多个版本。
- 用户可以从任意历史节点继续。
- 原分支不会被覆盖。

## 阶段 2：智能体任务状态

目标：让用户知道 Agent 在做什么、做到哪、下一步是什么。

范围：

- Agent task state
- Tool call timeline
- Running / paused / failed / completed
- External action warning

验收标准：

- 用户能看到智能体执行过程。
- 失败任务可恢复。
- 外部动作不可撤销时有明确提示。

## 阶段 3：长期计划与项目记忆

目标：解决长期项目容易丢主线的问题。

范围：

- Project plan
- Decision log
- Work log
- Context summary
- Branch summary

验收标准：

- 用户不用翻聊天记录也能知道当前主线。
- Agent 每次工作前能自动对齐项目计划。
- 重要转向都能在 `DECISIONS.md` 中找到原因。

## 阶段 4：多模态上下文管理

目标：让图片、文件、工具结果不会污染长期上下文，但在需要时能被准确引用。

范围：

- image_ref
- file_ref
- visual summary
- structured observations
- source attachment policy

验收标准：

- 普通追问只带摘要。
- 视觉编辑、比较、细节判断时重新带原图。
- 对话历史不重复塞入图片本体。

