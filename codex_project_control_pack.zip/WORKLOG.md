# WORKLOG.md

## 2026-06-18

### 本次完成

- 明确 UIChat 的核心对话模型方向。
- 确定重新生成使用 `MessageVersion`。
- 确定编辑历史消息产生 `ConversationBranch`。
- 确定分支默认弱展示，优先用“版本”和“从这里继续”表达。
- 确定外部动作不随对话分支自动回滚。

### 修改文件

- `AGENTS.md`
- `PROJECT.md`
- `ROADMAP.md`
- `PLAN.md`
- `DECISIONS.md`
- `TODO.md`

### 遗留问题

- 工具调用结果是否允许跨分支复用？
- 外部动作如何在 UI 中提示不可撤销？
- 分支 UI 默认隐藏还是以轻量入口展示？
- 多模态图片上下文应该如何进入长期记忆？

### 下一步建议

优先定义数据库模型：

- Conversation
- Message
- MessageVersion
- ConversationBranch
- BranchCursor
- ToolCall
- ToolResult

