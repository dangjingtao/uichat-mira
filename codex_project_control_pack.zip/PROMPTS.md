# PROMPTS.md

## 开始任务前

```txt
请先阅读 AGENTS.md、PROJECT.md、ROADMAP.md、PLAN.md、DECISIONS.md 和 TODO.md。

然后告诉我：
1. 当前项目主线是什么
2. 本次任务是否符合主线
3. 你建议下一步做什么

在我确认前，不要修改代码。
```

## 执行当前主线任务

```txt
请根据 PLAN.md 的当前主线，只完成 TODO.md 中 Now 区的第一项。

要求：
1. 先给执行计划
2. 不要扩大范围
3. 不要重构无关代码
4. 完成后更新 WORKLOG.md
5. 如果产生新决策，更新 DECISIONS.md
```

## 判断临时想法

```txt
我有一个新想法：XXX。

请不要立刻实现。
先判断它属于：
- 当前 PLAN.md 主线
- Next
- Later
- 或者应该放弃

然后说明原因。
```

## 防止跑偏

```txt
请检查当前任务是否偏离 PLAN.md。

如果偏离：
1. 说明当前主线是什么
2. 说明偏离点在哪里
3. 建议是否放入 TODO.md 的 Next 或 Later
4. 在我确认前不要实现
```

## 阶段复盘

```txt
请根据 WORKLOG.md、DECISIONS.md 和 TODO.md，做一次阶段复盘：

1. 已完成什么
2. 哪些决策已经固定
3. 当前最大风险是什么
4. 下一步最应该做什么
5. 哪些任务应该推迟
```

